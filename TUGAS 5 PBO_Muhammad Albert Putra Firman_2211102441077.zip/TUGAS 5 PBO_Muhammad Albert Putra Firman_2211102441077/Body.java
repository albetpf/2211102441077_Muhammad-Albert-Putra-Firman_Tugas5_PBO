import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
public class Body extends Actor 
{
    private int age = 0;
    private int lifespan;
    
    public Body(int lifespan) {
        this.lifespan = lifespan;
    }

    public void act() {
        if (age == lifespan) {
            getWorld().removeObject(this);
        }
        age++;
    }
}