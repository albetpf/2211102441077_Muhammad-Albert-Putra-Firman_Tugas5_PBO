import greenfoot.*;

public class MyWorld extends World {
    private int score;

    public MyWorld() {    
        super(600, 600, 1); 
        int x = Greenfoot.getRandomNumber(getWidth());
        int y = Greenfoot.getRandomNumber(getHeight());
        addObject(new SnakeHead(), x, y);
        addFood();
        showScore(); 
        prepare();
    }

    public void addFood() {
        int x = Greenfoot.getRandomNumber(getWidth());
        int y = Greenfoot.getRandomNumber(getHeight());
        addObject(new Food(this), x, y);
    }

    public void increaseScore() {
        score++;
        showScore();
    }

    public void showScore() {
        showText("Score: " + score, 50, 20);
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}
